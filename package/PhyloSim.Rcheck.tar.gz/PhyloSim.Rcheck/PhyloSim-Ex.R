pkgname <- "PhyloSim"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('PhyloSim')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
base::assign(".old_wd", base::getwd(), pos = 'CheckExEnv')
cleanEx()
nameEx("SQLite-TSI")
### * SQLite-TSI

flush(stderr()); flush(stdout())

### Name: SQLite-TSI
### Title: SQLite Trait Simulation Interface
### Aliases: SQLite-TSI connectNetwork ClearNetwork makeLinearNetwork
###   makeTreeNetwork makeReticulatedNetwork clearNetwork drawDNASequence
###   drawEvolRate simulateSequence simulateTrait getSequence

### ** Examples

## Load the example of a configuration file provided with the
## package:
system.file(
  package = "PhyloSim",
  "extdata",
  "evolMod.yml"
) %>%
  yaml.load_file -> dnaParam

## The configuration list is located in member `$DNA`
dnaParam$DNA %>%
  read.mutationMat -> I

## The transition intensity matrix:
I

## The trait evolution model parameters:
dnaParam$trait %>%
  lapply(read.TraitEvolMod) -> traitMod


### Linear case:

## Initializing a new data base to store the network:
net <- connectNetwork(name = "net_linear", init = TRUE)

## Setting RNG seed to have a consistent example:
set.seed(162745)

## These are the tables that are created in the database:
dbListTables(net$con)

## The following code enables one to extract the SQLite table information:
lapply(
  dbListTables(net$con),
  function(x, con)
    dbGetQuery(con, sprintf("PRAGMA table_info(%s)", x)),
  con = net$con
) -> table_info

names(table_info) <- dbListTables(net$con)

table_info

## The following code retrieves the number of records in all the tables.
## All of them are empty at the beginning of the simulation:
sapply(
  dbListTables(net$con),
  function(x, con)
    unlist(
      dbGetQuery(
        con,
        sprintf(
          "SELECT COUNT(*) AS %s
         FROM %s",
          x,x),
      )
    ),
  con = net$con
)

## Create a linear network with 50 species having 1 descendant each with a
## constant time step of 1:
makeLinearNetwork(
  net = net,
  NS = 50,
  NC = function() 1,
  timestep = function() 1,
  root = TRUE,
  verbose = TRUE
)

## After the linear phylogenetic network has been created, tables diss, edge,
## and node conntain information. The other tables are used for storing the
## sequence and trait information.
sapply(
  dbListTables(net$con),
  function(x, con)
    unlist(
      dbGetQuery(
        con,
        sprintf("SELECT COUNT(*) FROM %s", x),
      )
    ),
  con = net$con
)

## Simulate two sequences, one named 'SEQ1' having 100 locations (i.e., one
## of the four nucleotide or a gap) and a second sequence named 'SEQ2' having
## 250 locations.
data.frame(
  name = c("SEQ1","SEQ2"),
  NN = c(100,250)
) -> cond

## Calling function simulateSequence once for each of the simulated
## sequences, each time drawing a random root sequence (using
## drawDNASequence) and a set of evolution rate (using function
## drawEvolRate).
for(i in 1:NROW(cond))
  simulateSequence(
    net,
    I,
    name = cond$name[i],
    sqn = drawDNASequence(cond$NN[i]),
    rate = drawEvolRate(cond$NN[i])
  )

## Now, tables seq and seq_content contain information:
sapply(
  dbListTables(net$con),
  function(x, con)
    unlist(
      dbGetQuery(
        con,
        sprintf("SELECT COUNT(*) FROM %s", x),
      )
    ),
  con = net$con
)

## Show the first sequence (here, the y-axis corresponds to the time step):
net %>%
  getSequence(name = "SEQ1") %>%
  concatenate(discard = "-") %>%
  show.sequence

## Show the second sequence:
net %>%
  getSequence(name = "SEQ2") %>%
  concatenate(discard = "-") %>%
  show.sequence

## Set four traits to be simulated.
data.frame(
  name = sprintf("trait%d",1:4),
  state = c(2,NA,1,1),
  value = c(50,0,15,-25),
  note = c("Non-neutral (OU) with multiple optima","Neutral",
           "Non-neutral (OU) with single optimum",
           "Non-neutral (OU) with single optimum")
) -> cond

## The four traits are simulated as follows:
for(i in 1:NROW(cond))
  simulateTrait(
    net,
    tem = traitEvolMod(traitMod[[i]]),
    name = cond$name[i],
    state = cond$state[i],
    value = cond$value[i],
    note = cond$note[i]
  )

## Now, tables trait and trait_content also contain information:
sapply(
  dbListTables(net$con),
  function(x, con)
    unlist(
      dbGetQuery(
        con,
        sprintf("SELECT COUNT(*) FROM %s", x),
      )
    ),
  con = net$con
)

## To obtain the trait values at the nodes, one has to use an SQL query (in
## the SQLite dialect) as follows:
lapply(
  sprintf("trait%d",1:4),
  function(x, con)
    dbGetQuery(
      con,
      sprintf(
        "SELECT trait_content.node, trait_content.optim, trait_content.value
         FROM trait_content
         JOIN trait ON trait.rowid = trait_content.trait
         WHERE trait.name = '%s'
         ORDER BY trait_content.node",
        x
      )
    ),
  con = net$con
) -> sim_trait

## Plot the trait simulation results:
par(mar=c(4,4,1,1))
plot(NA, xlim=c(0,50), xlab="Time", ylab="Trait value", las=1,
     ylim=range(-25,sapply(sim_trait, function(x) x$value),80))
col <- c("black","red","blue","green")

## The solid line is the trait value, whereas the dotted line is the
## effective trait optimum:
for(i in 1:4) {
  lines(x=0:49, y=sim_trait[[i]]$value, col=col[i])
  if(!all(is.na(sim_trait[[i]]$optim)))
    lines(x=0:49, y=sim_trait[[i]]$optim, col=col[i], lty=3)
}
## Note: there are no effective optimum for a trait evolving neutrally.

## Clear the simulated linear network:
clearNetwork(net, TRUE)


### Tree case:

## Initializing a new data base to store the network:
net <- connectNetwork(name = "net_linear", init = TRUE)

## Setting RNG seed to have a consistent example:
set.seed(162745)

## Create a tree network (phylogenetic tree) with 100 species having
## a fix number of 2 descendants (dichotomic) and a random log-normal time
## step drawn at each time step:
makeTreeNetwork(
  net = net,
  NS = 100,
  NC = function() 2,
  timestep = function() exp(rnorm(1,0,0.5)),
  root = TRUE,
  verbose = TRUE
)

## Simulate two sequences, one named 'SEQ1' having 50 locations (i.e., one of
## the four nucleotide or a gap) and a second sequence named 'SEQ2' having 80
## locations.
data.frame(
  name = c("SEQ1","SEQ2"),
  NN = c(50,80)
) -> cond

## Calling function simulateSequence once for each of the simulated
## sequences, each time drawing a random root sequence (using
## drawDNASequence) and a set of evolution rate (using function
## drawEvolRate).
for(i in 1:NROW(cond))
  simulateSequence(
    net,
    I,
    name = cond$name[i],
    sqn = drawDNASequence(cond$NN[i]),
    rate = 10*drawEvolRate(cond$NN[i])  ## Accelerate evolution by 10 folds
  )

## Set four traits to be simulated.
data.frame(
  name = sprintf("trait%d",1:4),
  state = c(2,NA,1,1),
  value = c(50,0,15,-25),
  note = c("Non-neutral (OU) with multiple optima","Neutral",
           "Non-neutral (OU) with single optimum",
           "Non-neutral (OU) with single optimum")
) -> cond

## The four traits are simulated as follows:
for(i in 1:NROW(cond))
  simulateTrait(
    net,
    tem = traitEvolMod(traitMod[[i]]),
    name = cond$name[i],
    state = cond$state[i],
    value = cond$value[i],
    note = cond$note[i]
  )

## To obtain the trait values at the nodes, one has to use an SQL query (in
## the SQLite dialect) as follows:
lapply(
  sprintf("trait%d",1:4),
  function(x, con)
    dbGetQuery(
      con,
      sprintf(
        "SELECT trait_content.node, trait_content.optim, trait_content.value
         FROM trait_content
         JOIN trait ON trait.rowid = trait_content.trait
         WHERE trait.name = '%s'
         ORDER BY trait_content.node",
        x
      )
    ),
  con = net$con
) -> sim_trait

## Showing the sequences and traits evolving is not as straightforward for a
## phylogenetic tree as it is for a linear sequence of descendants.

## We first need to retrieve the edge list as follows:
dbGetQuery(
  net$con,
  "SELECT i,j FROM edge ORDER BY rowid"
) -> edge

## From that list, we can determine which node is a leaf:
leaf <- edge$j[!(edge$j %in% unique(edge$i))]
leaf

## We can use this simple function to obtain lineage of any node:
getLineage <- function(x, e) {
  while(length(wh <- which(e$j == head(x,1))))
    x <- c(e$i[wh], x)
  unname(x)
}

## Here is the lineage of the first leaf:
getLineage(leaf[1], edge)

## Show the first sequence (here, the y-axis corresponds to the time step):
net %>%
  getSequence(name = "SEQ1") %>%
  .[getLineage(leaf[1], edge),] %>%
  concatenate(discard = "-") %>%
  show.sequence

## Show the second sequence:
net %>%
  getSequence(name = "SEQ2") %>%
  .[getLineage(leaf[1], edge),] %>%
  concatenate(discard = "-") %>%
  show.sequence

## Obtain the distances between the root node and all the nodes:
rbind(
  list(1L,0),
  dbGetQuery(
    net$con,
    "SELECT j, d FROM diss WHERE i = 1 ORDER BY j"
  )
) -> dst

## Function to show every lineages 'l':
plotit <- function(l) {
  nn <- getLineage(leaf[l], edge)
  dd <- dst$d[match(nn, dst$j)]
  
  ## Plot the trait simulation results:
  par(mar=c(4,4,1,1))
  plot(NA, xlim=range(dd), xlab="Time", ylab="Trait value", las=1,
       ylim=range(-25,sapply(sim_trait, function(x) x$value),80))
  col <- c("black","red","blue","green")
  
  ## The solid line is the trait value, whereas the dotted line is the
  ## effective trait optimum:
  for(i in 1:4) {
    lines(x=dd, y=sim_trait[[i]]$value[match(nn, dst$j)], col=col[i])
    if(!all(is.na(sim_trait[[i]]$optim)))
      lines(x=dd, y=sim_trait[[i]]$optim[match(nn, dst$j)], col=col[i],
            lty=3)
  }
  ## Note: there are no effective optimum for a trait evolving neutrally.
}

## Plot the lineages of some of the leaves:
plotit(1)
plotit(2)
plotit(3)
plotit(6)
plotit(7)

## Clear the simulated linear network:
clearNetwork(net, TRUE)


### The reticulated case:

## Initializing a new data base to store the network:
net <- connectNetwork(name = "net_reticulated", init = TRUE)
## clearNetwork(net, TRUE)

## Setting RNG seed to have a consistent example:
set.seed(162745)

## Create a reticulated network with 100 species having a random number of
## descendants and parents per node, a random log-normal time step, a random
## maximum hybridization distance, and equal parental contributions on
## hybridization events.
makeReticulatedNetwork(
  net,
  NS = 100,
  NC = function() 1 + rpois(1,2),
  NP = function() 1 + rpois(1,1),
  timestep = function() exp(rnorm(1,0,0.5)),
  maxDiss = function() runif(1, 2, 3),
  contrib = function(x) rep(1/x,x),
  root = TRUE,
  verbose = TRUE
)

## Simulate one sequence named 'SEQ1' having 50 locations (i.e., one of
## the four nucleotide or a gap). Calling function simulateSequence drawing a
## random root sequence (using drawDNASequence) and a set of evolution rate
## (using function drawEvolRate).
simulateSequence(
  net,
  I,
  name = "SEQ1",
  sqn = drawDNASequence(50),
  rate = 10*drawEvolRate(50)  ## Accelerate evolution by 10 folds
)

## Set four traits to be simulated.
data.frame(
  name = sprintf("trait%d",1:4),
  state = c(2,NA,1,1),
  value = c(50,0,15,-25),
  note = c("Non-neutral (OU) with multiple optima","Neutral",
           "Non-neutral (OU) with single optimum",
           "Non-neutral (OU) with single optimum")
) -> cond

## The four traits are simulated as follows:
for(i in 1:NROW(cond))
  simulateTrait(
    net,
    tem = traitEvolMod(traitMod[[i]]),
    name = cond$name[i],
    state = cond$state[i],
    value = cond$value[i],
    note = cond$note[i]
  )

## To obtain the trait values at the nodes, one has to use an SQL query (in
## the SQLite dialect) as follows:
lapply(
  sprintf("trait%d",1:4),
  function(x, con)
    dbGetQuery(
      con,
      sprintf(
        "SELECT trait_content.node, trait_content.optim, trait_content.value
         FROM trait_content
         JOIN trait ON trait.rowid = trait_content.trait
         WHERE trait.name = '%s'
         ORDER BY trait_content.node",
        x
      )
    ),
  con = net$con
) -> sim_trait

## Showing the sequences and traits evolving is even less straightforward for
## a reticulated phylogenetic network as it is for a phylogenetic tree, let
## alone for a linear sequence of descendants.

## We first need to retrieve the edge list as follows (same as for a tree):
dbGetQuery(
  net$con,
  "SELECT i,j FROM edge ORDER BY rowid"
) -> edge

## From that list, we can determine which node is a leaf (also same as for a
## tree):
leaf <- unique(edge$j[!(edge$j %in% unique(edge$i))])
leaf

## Obtain the distances between the root node and all the nodes:
rbind(
  list(1L,0),
  dbGetQuery(
    net$con,
    "SELECT j, d FROM diss WHERE i = 1 ORDER BY j"
  )
) -> dst

## To obtain simple lineage, we need a criterion to choose which parent to
## follow at hybridization events. Here, the parent that is the closest to
## the root is the one chosen:
getLineageDR <- function(x, e, d) {
  while(length(wh <- which(e$j == head(x,1)))) {
    wh <- wh[which.min(d$d[match(e$i[wh],d$j)])]
    x <- c(e$i[wh], x)
  }
  unname(x)
}

## Here is the lineage of the first leaf of the network:
getLineageDR(leaf[1], edge, dst)

## Show the sequences of the lineage of the first leaf:
net %>%
  getSequence(name = "SEQ1") %>%
  .[getLineageDR(leaf[1], edge, dst),] %>%
  concatenate(discard = "-") %>%
  show.sequence

## Show the sequences of the lineage of the second leaf:
net %>%
  getSequence(name = "SEQ1") %>%
  .[getLineageDR(leaf[2], edge, dst),] %>%
  concatenate(discard = "-") %>%
  show.sequence

## Show the sequences of the lineage of the third leaf:
net %>%
  getSequence(name = "SEQ1") %>%
  .[getLineageDR(leaf[6], edge, dst),] %>%
  concatenate(discard = "-") %>%
  show.sequence

## Function to show every lineages 'l':
plotit <- function(l) {
  nn <- getLineageDR(leaf[l], edge, dst)
  dd <- dst$d[match(nn, dst$j)]
  
  ## Plot the trait simulation results:
  par(mar=c(4,4,1,1))
  plot(NA, xlim=range(dd), xlab="Time", ylab="Trait value", las=1,
       ylim=range(-25,sapply(sim_trait, function(x) x$value),80))
  col <- c("black","red","blue","green")
  
  ## The solid line is the trait value, whereas the dotted line is the
  ## effective trait optimum:
  for(i in 1:4) {
    lines(x=dd, y=sim_trait[[i]]$value[match(nn, dst$j)], col=col[i])
    if(!all(is.na(sim_trait[[i]]$optim)))
      lines(x=dd, y=sim_trait[[i]]$optim[match(nn, dst$j)], col=col[i],
            lty=3)
  }
  ## Note: there are no effective optimum for a trait evolving neutrally.
}

## Plot the lineages of some of the leaves:
plotit(7)
plotit(15)
plotit(22)
plotit(length(leaf))

## Clear the simulated linear network:
clearNetwork(net, TRUE)




graphics::par(get("par.postscript", pos = 'CheckExEnv'))
cleanEx()
nameEx("concatenate")
### * concatenate

flush(stderr()); flush(stdout())

### Name: concatenate
### Title: Sequence Concatenation
### Aliases: concatenate

### ** Examples

## Define a raw vector for storing nuceotide values:
c(Sequence_1 = "ATCG-TTTCG--CCCCA--TTA--TTAA-GTAA-GTAATCTTTCA",
  Sequence_2 = "TTGGCTTCC--TC--CAT-TTC--TTCA-GT-ACG-ATTCTTTTA",
  Sequence_3 = "TTCG-TACC-T-T---A-ATAA--T-AA-GTCTTGTAATCGTTCA") %>%
  sapply(charToRaw) %>%
  t -> sqn

## Display the raw sequence:
sqn

## Transforming the sequence to character strings
concatenate(sqn)

## Transforming the sequence to character strings without the gaps:
concatenate(sqn, discard="-")

## Clean-up:
rm(sqn)




cleanEx()
nameEx("dst_idx")
### * dst_idx

flush(stderr()); flush(stdout())

### Name: dst_idx
### Title: Distance Vector Indexing
### Aliases: dst_idx

### ** Examples

### Here...







cleanEx()
nameEx("molEvolMod")
### * molEvolMod

flush(stderr()); flush(stdout())

### Name: molEvolMod
### Title: Molecular Evolution Simulator
### Aliases: molEvolMod read.mutationMat

### ** Examples

## Load the example of a configuration file provided with the
## package:
yaml.load_file(
  system.file(
    package = "PhyloSim",
    "extdata",
    "evolMod.yml"
  )
) -> dnaParam

## The configuration list is located in member `$DNA`
read.mutationMat(
  dnaParam$DNA 
) -> I

## The transition intensity matrix:
I

## Implement the molecular evolution model for a single nucleotide:
molEvolMod(I, 1, 1) -> em1

## Get the transition probability matrix as follows:
em1$getMt()

## A vector of raw as examples of initial traits:
tr <- charToRaw("-ACGT")

## Simulate molecular evolution from:
rawToChar(em1$evolve(tr[1L]))    ## a gap.
rawToChar(em1$evolve(tr[2L]))    ## an adenine base.
rawToChar(em1$evolve(tr[3L]))    ## a cytosine base.
rawToChar(em1$evolve(tr[4L]))    ## a guanine base.
rawToChar(em1$evolve(tr[5L]))    ## a thymine base.

## Recalculate the probabilities for a lower mean evolution rate (one tenth
## the previous one):
em1$recalculate(1, 0.1)

em1$getMt()        ## The recalculated transition probability matrix.

## Simulate molecular evolution from:
rawToChar(em1$evolve(tr[1L]))    ## a gap.
rawToChar(em1$evolve(tr[2L]))    ## an adenine base.
rawToChar(em1$evolve(tr[3L]))    ## a cytosine base.
rawToChar(em1$evolve(tr[4L]))    ## a guanine base.
rawToChar(em1$evolve(tr[5L]))    ## a thymine base.

## Base changes are now less probable.

## Clean up:
rm(em1, tr)




cleanEx()
nameEx("show.sequence")
### * show.sequence

flush(stderr()); flush(stdout())

### Name: show.sequence
### Title: Show DNA Sequences
### Aliases: show.sequence

### ** Examples

## A set of exemplary DNA sequences:
sqn <- c(Sequence_0 = "ATCG-TTT-G--C--CA--TTA--TTAA-GTGC-GTGGTCT-TCA",
         Sequence_1 = "ATCG-TTTCG--CCCCA--TTA--TTAA-GTAA-GTAATCTTTCA",
         Sequence_2 = "TTGGCTTCC--TC--CAT-TTC--TTCA-GT-ACG-ATTCTTTTA",
         Sequence_3 = "TTCG-TACC-T-T---A-ATAA--T-AA-GTCTTGTAATCGTTCA",
         Sequence_4 = "TTCG-TACC-T-T-T-C-ATAA--T-AA-GTCTGGTGGTCGTTCA",
         Sequence_5 = "TTCG-TACG-T-T-T-C-ATAT--T-AA-GTCTGGTGGTCGTTCA",
         Sequence_6 = "TTCG-TACG-T-T-T-GATTTT--T-AA-GTCTGGT---CGTTCA",
         Sequence_7 = "TTAG-TACG-T-T-T-GATTTT--T-TT-G---GGT---CGTTTT",
         Sequence_8 = "TTAG-TACG-T-T-T-GATTTT--T-TT-G---GA----CGTTTT",
         Sequence_9 = "TTAG-TACG-TATCT-GAT--TAAT-TT-G---GA----CG--TA")

## With all the defaults:
show.sequence(sqn)

## Displays the nucleotides and the gaps:
show.sequence(sqn, text=TRUE, cex=0.75)

## Clean up:
rm(sqn)




cleanEx()
nameEx("traitEvolMod")
### * traitEvolMod

flush(stderr()); flush(stdout())

### Name: traitEvolMod
### Title: Trait Evolution Simulator
### Aliases: traitEvolMod read.TraitEvolMod TEM-class print.TEM

### ** Examples

## Load the example of a configuration file provided with the
## package:
yaml.load_file(
  system.file(
    package = "PhyloSim",
    "extdata",
    "evolMod.yml"
  )
) -> dnaParam

## This file contains four trait configurations.

## The first trait file appears as follows:

dnaParam$trait[[1]]

## The second, third, fourth appears as follows:

dnaParam$trait[[2]]

dnaParam$trait[[3]]

## and

dnaParam$trait[[4]]

## The configuration list is obtained from the raw file as follows:

cfg <- read.TraitEvolMod(dnaParam$trait[[1]])
cfg

## All four lists are obtained as follows:

cfg <- lapply(dnaParam$trait, read.TraitEvolMod)

cfg[[1]]

cfg[[2]]

cfg[[3]]

cfg[[4]]

## The four trait evolution models can also be obtained at once as
## follows:
tem <- lapply(cfg, traitEvolMod)

## The first model is non-neutral with three optima:
tem[[1]]

## The second model is neutral:
tem[[2]]

## The third model is non-neutral with a single optimum:
tem[[3]]

## The fourth trait is also non-neutral with a single optimum (but having a
## different value than the latter):
tem[[4]]

## Each model has a set of embedded member functions that can be called
## directly.

## Member $getName() returns the name of the trait as follows:
unlist(lapply(tem, function(x) x$getName()))

## Member $getStep() returns the step sizes for the traits as follows:
unlist(lapply(tem, function(x) x$getStep()))

## Member $setStep() sets the step sizes as follows:
lapply(tem, function(x) x$setStep(0.1))

## and returns the recalculated transition probability matrix of models
## having a transition intensity matrix (i.e., for non-neutral models with
## multiple trait optima).

## This is the modified step sizes:
unlist(lapply(tem, function(x) x$getStep()))

## Member $getOptima() returns the model optimum (if available) or a vector
## of model optima (if multiple optima are available) as follows:
lapply(tem, function(x) x$getOptima())

## Member $getTransition() returns the transition intensity matrix, when
## available (NULL otherwise) as follows:
lapply(tem, function(x) x$getTransition())

## Member $getProb() returns the transition intensity matrix, whenever
## available (NULL otherwise) as follows:
lapply(tem, function(x) x$getProb())

## When multiple optima are available, member $updateState() enables to
## simulate the transition from one optimal trait state (the one given as the
## argument) to another (the one which is returned by the function):
state <- 1
newstate <- tem[[1]]$updateState(state)
newstate

## Member $updateValue() simulates the evolution of the trait from one value
## to another. For a non-neutral with multiple optima, The trait state is
## provided using argument state (default: 1, which is the only applicable
## value for a single optimum).
oldvalue <- 31.5
newvalue <- tem[[1]]$updateValue(oldvalue, state=1)
newvalue

## Member $dumpConfig() returns the configuration list, which can be used

cfg2 <- lapply(tem, function(x) x$dumpConfig())
tem2 <- lapply(cfg2, traitEvolMod)
tem2

## Clean up:
rm(cfg2, tem2)

## Simulate trait evolution using the four models described previously:

## Set step size to 0.05
lapply(tem, function(x, a) x$setStep(a), a = 0.05)

## Results list:
res <- NULL
trNms <- lapply(tem, function(x) x$getName())
res$state <- matrix(NA, 1001L, length(tem), dimnames = list(NULL, trNms))
res$optim <- matrix(NA, 1001L, length(tem), dimnames = list(NULL, trNms))
res$trait <- matrix(NA, 1001L, length(tem), dimnames = list(NULL, trNms))
rm(trNms)

## res$state contains the trait state at the simulation time
## res$optim contains the trait's optimum value at the simulation time
## res$trait contains the trait value at the simulation time

## Setting the optimal state of the four traits at the beginning of the
## simulation period:
res$state[1L,] <- c(2,NA,1,1)  ## NBL trait #2 evolves neutrally.

## Getting the trait optima at the beginning of the simulation period:
unlist(
  lapply(
    tem,
    function(x)
      x$getOptima()[res$state[1L,x$getName()]]
  )
) -> res$optim[1L,]

## Setting the initial trait values:
res$trait[1L,] <- c(50,0,15,-25)

## The state of the simulation at the beginning of the simulation:
head(res$state)
head(res$optim)
head(res$trait)

## Setting RNG state to obtain 
set.seed(1234567)

## This loop simulates time steps #2 through #1001
for(i in 2L:1001L) {

  ## Simulate the evolution of the trait states (if relevant, which it is
  ## only for the first trait):
  unlist(
    lapply(
      tem,
      function(x)
        x$updateState(res$state[i - 1L,x$getName()])
    ) 
  )-> res$state[i,]
  
  ## Obtain the optimal trait value (relevant for all traits but the second,
  ## trait, which evolves neutrally):
  unlist(
    lapply(
      tem,
      function(x)
        x$getOptima()[res$state[i,x$getName()]]
    )
  ) -> res$optim[i,]
  
  ## Simulate the evolution of the trait value:
  unlist(
    lapply(
      tem,
      function(x)
        x$updateValue(
          state = res$state[i,x$getName()],
          value = res$trait[i - 1L,x$getName()]
        )
    )
  ) -> res$trait[i,]
}

## Plot the results:
par(mar=c(4,4,1,1))
plot(NA, xlim=c(0,0.05*1000), ylim=range(res$trait), xlab="Time",
     ylab="Trait value", las=1L)
lines(x=0.05*(0:1000), y=res$trait[,1L], col="black")
if(!is.na(tem[[1L]]$getOptima())[1L])
  lines(x=0.05*(0:1000), y=res$optim[,1L], col="black", lty=3L)
lines(x=0.05*(0:1000), y=res$trait[,2L], col="red")
if(!is.na(tem[[2L]]$getOptima())[1L])
  lines(x=0.05*(0:1000), y=res$optim[,2L], col="red", lty=3L)
lines(x=0.05*(0:1000), y=res$trait[,3L], col="blue")
if(!is.na(tem[[3L]]$getOptima())[1L])
  lines(x=0.05*(0:1000), y=res$optim[,3L], col="blue", lty=3L)
lines(x=0.05*(0:1000), y=res$trait[,4L], col="green")
if(!is.na(tem[[4L]]$getOptima())[1L])
  lines(x=0.05*(0:1000), y=res$optim[,4L], col="green", lty=3L)

## Save the figure to a PNG file:
dev.copy(png, filename="Trait value simulation (linear).png", width=600,
height=400)
dev.off()




graphics::par(get("par.postscript", pos = 'CheckExEnv'))
cleanEx()
nameEx("write.fasta")
### * write.fasta

flush(stderr()); flush(stdout())

### Name: write.fasta
### Title: Write Sequences to a FASTA Text File
### Aliases: write.fasta

### ** Examples

## Define a raw vector for storing nuceotide values:
c(Sequence_1 = "ATCG-TTTCG--CCCCA--TTA--TTAA-GTAA-GTAATCTTTCA",
  Sequence_2 = "TTGGCTTCC--TC--CAT-TTC--TTCA-GT-ACG-ATTCTTTTA",
  Sequence_3 = "TTCG-TACC-T-T---A-ATAA--T-AA-GTCTTGTAATCGTTCA") %>%
  sapply(charToRaw) %>%
  t -> sqn

## Display the raw sequence:
sqn

## Transforming the sequence to character strings
tmp <- concatenate(sqn)
tmp

## Transforming the sequence to character strings without the gaps:
concatenate(sqn, discard="-")

## Write the sequences into a text file:
write.fasta(tmp, file="Sequences.fst", linebreak=15)

## Clean-up:
file.remove("Sequences.fst")
rm(sqn, tmp)




### * <FOOTER>
###
cleanEx()
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
